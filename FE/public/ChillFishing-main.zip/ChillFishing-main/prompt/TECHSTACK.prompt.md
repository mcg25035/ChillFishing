# backend: 
- NodeJS
- Express
- SocketIO
- Sqlite
- Dotenv

# frontend:
- React
- Axios (不使用複雜的 SWR 、 Redux 等等進行實做，因為只有很簡單幾個API Endpoints)
- SocketIO